APviEwer Repo Preview — static connectivity test only.
